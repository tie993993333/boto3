# commands/start_cmd.py
import sqlite3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from db import DATABASE

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """欢迎消息，注册新用户并展示内联菜单。"""
    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE telegram_id = ?", (user.id,))
    if c.fetchone() is None:
        c.execute("INSERT INTO users (telegram_id, balance, language) VALUES (?, ?, ?)", (user.id, 0, 'zh'))
        conn.commit()
    conn.close()
    welcome_text = (
        f"欢迎使用商店机器人，{user.first_name}！\n"
        "您可以通过内联按钮直接查询部分库存信息，也可使用命令执行其他操作。\n\n"
        "或点击下方按钮查看常用信息："
    )
    keyboard = [
        [InlineKeyboardButton("全资库库存", callback_data="inventory")],
        [InlineKeyboardButton("全球混库存", callback_data="global_inventory")],
        [InlineKeyboardButton("卡头库存", callback_data="card_inventory")],
        [InlineKeyboardButton("售价信息", callback_data="pricing")],
        [InlineKeyboardButton("账户余额", callback_data="balance")],
        [InlineKeyboardButton("关闭菜单", callback_data="close")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(welcome_text, reply_markup=reply_markup)

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """展示内联键盘菜单，便于用户点击操作。"""
    keyboard = [
        [InlineKeyboardButton("全资库库存", callback_data="inventory")],
        [InlineKeyboardButton("全球混库存", callback_data="global_inventory")],
        [InlineKeyboardButton("卡头库存", callback_data="card_inventory")],
        [InlineKeyboardButton("售价信息", callback_data="pricing")],
        [InlineKeyboardButton("账户余额", callback_data="balance")],
        [InlineKeyboardButton("关闭菜单", callback_data="close")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("请选择操作：", reply_markup=reply_markup)
