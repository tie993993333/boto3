# commands/inventory_cmd.py
import sqlite3
from telegram import Update
from telegram.ext import ContextTypes
from db import DATABASE

async def inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """显示全资库库存列表。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, quantity, price FROM inventory")
    items = c.fetchall()
    conn.close()
    if not items:
        await update.message.reply_text("全资库库存为空。")
    else:
        message = "全资库库存列表：\n"
        for item in items:
            message += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await update.message.reply_text(message)

async def raw_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """显示裸库库存，仅管理员可用。"""
    from db import ADMIN_IDS  # 导入管理员 ID 列表
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("无权限使用此命令。")
        return
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT * FROM inventory")
    items = c.fetchall()
    conn.close()
    if not items:
        await update.message.reply_text("裸库库存为空。")
    else:
        message = "裸库库存数据：\n"
        for item in items:
            message += (
                f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]} | "
                f"供应商: {item[4]} | 区域: {item[5]} | 折扣: {item[6]}\n"
            )
        await update.message.reply_text(message)

async def global_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """显示全球混库存（region 为 'global' 的商品）。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, quantity, price FROM inventory WHERE region = 'global'")
    items = c.fetchall()
    conn.close()
    if not items:
        await update.message.reply_text("全球混库存为空。")
    else:
        message = "全球混库存列表：\n"
        for item in items:
            message += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await update.message.reply_text(message)

async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """根据关键词搜索商品。用法：/search 关键词"""
    if not context.args:
        await update.message.reply_text("请输入搜索关键词，例如：/search Card")
        return
    keyword = " ".join(context.args)
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, quantity, price FROM inventory WHERE name LIKE ?", ('%'+keyword+'%',))
    results = c.fetchall()
    conn.close()
    if not results:
        await update.message.reply_text("未找到相关商品。")
    else:
        message = "搜索结果：\n"
        for item in results:
            message += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await update.message.reply_text(message)

async def card_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """找头购买：搜索名称包含 'Card Header' 的商品，可附带关键词过滤。"""
    keyword = " ".join(context.args) if context.args else "Card Header"
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, quantity, price FROM inventory WHERE name LIKE ?", ('%'+keyword+'%',))
    results = c.fetchall()
    conn.close()
    if not results:
        await update.message.reply_text("未找到相关卡头商品。")
    else:
        message = "卡头搜索结果：\n"
        for item in results:
            message += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await update.message.reply_text(message)

async def card_inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """库存卡头查询：显示名称中包含 'Card Header' 的商品详细信息。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, quantity, price, supplier FROM inventory WHERE name LIKE '%Card Header%'")
    items = c.fetchall()
    conn.close()
    if not items:
        await update.message.reply_text("卡头库存为空。")
    else:
        message = "卡头库存查询：\n"
        for item in items:
            message += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]} | 供应商: {item[4]}\n"
        await update.message.reply_text(message)

async def pricing(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """显示售价信息：展示库存中每个商品的价格及折扣信息。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT id, name, price, discount FROM inventory")
    items = c.fetchall()
    conn.close()
    if not items:
        await update.message.reply_text("暂无售价信息。")
    else:
        message = "售价信息：\n"
        for item in items:
            final_price = item[2] - item[3] if item[3] > 0 else item[2]
            message += f"ID: {item[0]} | 名称: {item[1]} | 原价: {item[2]} | 折扣: {item[3]} | 折后价: {final_price}\n"
        await update.message.reply_text(message)
