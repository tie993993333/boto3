# commands/users_cmd.py
import sqlite3
from telegram import Update
from telegram.ext import ContextTypes
from db import DATABASE

async def balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """查询用户余额。"""
    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT balance FROM users WHERE telegram_id = ?", (user.id,))
    result = c.fetchone()
    conn.close()
    if result:
        await update.message.reply_text(f"您的余额为：{result[0]}")
    else:
        await update.message.reply_text("找不到您的用户记录，请先使用 /start 注册。")

async def recharge(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """充值操作，用法：/recharge 金额"""
    if not context.args:
        await update.message.reply_text("请输入充值金额，例如：/recharge 100")
        return
    try:
        amount = float(context.args[0])
    except ValueError:
        await update.message.reply_text("请输入有效的数字。")
        return

    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("UPDATE users SET balance = balance + ? WHERE telegram_id = ?", (amount, user.id))
    conn.commit()
    c.execute("SELECT balance FROM users WHERE telegram_id = ?", (user.id,))
    new_balance = c.fetchone()[0]
    conn.close()
    await update.message.reply_text(f"充值成功！您的新余额为：{new_balance}")

async def set_language(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """切换语言，用法：/language en 或 /language zh"""
    if not context.args:
        await update.message.reply_text("请输入语言代码，例如：/language en")
        return
    lang = context.args[0].lower()
    if lang not in ['en', 'zh']:
        await update.message.reply_text("仅支持 'en' 或 'zh' 两种语言。")
        return
    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("UPDATE users SET language = ? WHERE telegram_id = ?", (lang, user.id))
    conn.commit()
    conn.close()
    if lang == 'en':
        await update.message.reply_text("Language changed to English.")
    else:
        await update.message.reply_text("语言已切换为中文。")
