# commands/orders_cmd.py
import sqlite3
from telegram import Update
from telegram.ext import ContextTypes
from db import DATABASE

async def order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    下单购买商品，用法：/order 商品ID 数量
    示例：/order 1 2 表示购买 ID 为 1 的商品 2 个
    """
    if len(context.args) < 2:
        await update.message.reply_text("请输入商品ID和购买数量，例如：/order 1 2")
        return
    try:
        item_id = int(context.args[0])
        quantity = int(context.args[1])
    except ValueError:
        await update.message.reply_text("请输入有效的数字。")
        return

    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, quantity, price FROM inventory WHERE id = ?", (item_id,))
    item = c.fetchone()
    if not item:
        await update.message.reply_text("未找到该商品。")
        conn.close()
        return
    if item[1] < quantity:
        await update.message.reply_text("库存不足。")
        conn.close()
        return

    total_price = item[2] * quantity
    c.execute("SELECT balance FROM users WHERE telegram_id = ?", (user.id,))
    result = c.fetchone()
    if not result or result[0] < total_price:
        await update.message.reply_text("余额不足，请先充值。")
        conn.close()
        return

    new_balance = result[0] - total_price
    c.execute("UPDATE users SET balance = ? WHERE telegram_id = ?", (new_balance, user.id))
    c.execute("UPDATE inventory SET quantity = quantity - ? WHERE id = ?", (quantity, item_id))
    c.execute(
        "INSERT INTO orders (user_id, item_id, quantity, status) VALUES ((SELECT id FROM users WHERE telegram_id = ?), ?, ?, ?)",
        (user.id, item_id, quantity, '已购买')
    )
    conn.commit()
    conn.close()
    await update.message.reply_text(
        f"订单成功！您购买了 {quantity} 个 {item[0]}，总金额 {total_price}。新余额：{new_balance}"
    )

async def book(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    预定商品，用法：/book 商品ID 数量
    示例：/book 1 1 表示预定 ID 为 1 的商品 1 个
    """
    if len(context.args) < 2:
        await update.message.reply_text("请输入商品ID和预定数量，例如：/book 1 1")
        return
    try:
        item_id = int(context.args[0])
        quantity = int(context.args[1])
    except ValueError:
        await update.message.reply_text("请输入有效的数字。")
        return

    user = update.effective_user
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT name, quantity FROM inventory WHERE id = ?", (item_id,))
    item = c.fetchone()
    if not item:
        await update.message.reply_text("未找到该商品。")
        conn.close()
        return
    if item[1] < quantity:
        await update.message.reply_text("库存不足，无法预定。")
        conn.close()
        return

    c.execute(
        "INSERT INTO orders (user_id, item_id, quantity, status) VALUES ((SELECT id FROM users WHERE telegram_id = ?), ?, ?, ?)",
        (user.id, item_id, quantity, '预定')
    )
    conn.commit()
    conn.close()
    await update.message.reply_text(f"预定成功！您预定了 {quantity} 个 {item[0]}。请尽快完成支付。")
