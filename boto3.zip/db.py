# db.py
import sqlite3

DATABASE = 'store_bot.db'
ADMIN_IDS = [123456789]  # 请修改为实际管理员 Telegram ID

def init_db():
    """初始化数据库，创建必要的表。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    # 创建库存表，新增 region（库存区域）和 discount（折扣信息）
    c.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            supplier TEXT,
            region TEXT DEFAULT 'domestic',
            discount REAL DEFAULT 0
        )
    ''')
    # 创建用户表：记录 telegram_id、余额以及语言偏好（默认中文）
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE NOT NULL,
            balance REAL DEFAULT 0,
            language TEXT DEFAULT 'zh'
        )
    ''')
    # 创建订单表：记录购买或预定信息
    c.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(item_id) REFERENCES inventory(id)
        )
    ''')
    conn.commit()
    conn.close()

def add_sample_inventory():
    """添加示例库存数据，方便演示。"""
    conn = sqlite3.connect(DATABASE)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM inventory")
    count = c.fetchone()[0]
    if count == 0:
        sample_data = [
            # (name, quantity, price, supplier, region, discount)
            ('Card Header A', 10, 100.0, 'Supplier X', 'domestic', 0),
            ('Card Header B', 5, 150.0, 'Supplier Y', 'domestic', 10),
            ('Card Header C', 20, 80.0, 'Supplier Z', 'global', 0),
            ('普通商品 D', 50, 30.0, 'Supplier W', 'domestic', 0),
            ('全球商品 E', 15, 200.0, 'Supplier V', 'global', 20)
        ]
        c.executemany(
            "INSERT INTO inventory (name, quantity, price, supplier, region, discount) VALUES (?, ?, ?, ?, ?, ?)",
            sample_data
        )
        conn.commit()
    conn.close()
