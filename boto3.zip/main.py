# commands/buttons.py
import sqlite3
from telegram import Update
from telegram.ext import ContextTypes
from db import DATABASE

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """处理内联键盘按钮点击事件，并返回相应查询结果。"""
    query = update.callback_query
    await query.answer()  # 确认回调
    data = query.data

    if data == "inventory":
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, name, quantity, price FROM inventory")
        items = c.fetchall()
        conn.close()
        text = "全资库库存列表：\n" if items else "全资库库存为空。"
        for item in items:
            text += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await query.edit_message_text(text=text)
    elif data == "global_inventory":
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, name, quantity, price FROM inventory WHERE region = 'global'")
        items = c.fetchall()
        conn.close()
        text = "全球混库存列表：\n" if items else "全球混库存为空。"
        for item in items:
            text += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]}\n"
        await query.edit_message_text(text=text)
    elif data == "card_inventory":
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, name, quantity, price, supplier FROM inventory WHERE name LIKE '%Card Header%'")
        items = c.fetchall()
        conn.close()
        text = "卡头库存查询：\n" if items else "卡头库存为空。"
        for item in items:
            text += f"ID: {item[0]} | 名称: {item[1]} | 数量: {item[2]} | 价格: {item[3]} | 供应商: {item[4]}\n"
        await query.edit_message_text(text=text)
    elif data == "pricing":
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT id, name, price, discount FROM inventory")
        items = c.fetchall()
        conn.close()
        text = "售价信息：\n" if items else "暂无售价信息。"
        for item in items:
            final_price = item[2] - item[3] if item[3] > 0 else item[2]
            text += f"ID: {item[0]} | 名称: {item[1]} | 原价: {item[2]} | 折扣: {item[3]} | 折后价: {final_price}\n"
        await query.edit_message_text(text=text)
    elif data == "balance":
        user = query.from_user
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute("SELECT balance FROM users WHERE telegram_id = ?", (user.id,))
        result = c.fetchone()
        conn.close()
        text = f"您的余额为：{result[0]}" if result else "找不到您的用户记录，请先使用 /start 注册。"
        await query.edit_message_text(text=text)
    elif data == "close":
        await query.edit_message_text(text="菜单已关闭。")
    else:
        await query.edit_message_text(text="未知操作。")
